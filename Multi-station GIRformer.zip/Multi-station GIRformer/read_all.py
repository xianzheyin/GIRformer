from function import readHKQT
from function import readSC02
from function import readTPW2
from function import readSPBY
#from function import readBRST
from function import readGTGU
def add_data(dataset,add_data):
    for i in range(34):
        for j in range(len(add_data[i])):
            dataset[i].append(add_data[i][j])
    return dataset
def start(list_station,type,max_ele=30):
    dataset=[]
    for _ in range(34):dataset.append([])
    if "HKQT" in list_station:dataset=add_data(dataset,readHKQT.read(type,max_ele))
    if "SPBY" in list_station:dataset=add_data(dataset,readSPBY.read(type,max_ele))
    if "SC02" in list_station:dataset=add_data(dataset,readSC02.read(type,max_ele))
    if "TPW2" in list_station:dataset=add_data(dataset,readTPW2.read(type,max_ele))
    #if "BRST" in list_station:dataset=add_data(dataset,readBRST.read(type,max_ele))
    if "GTGU" in list_station:dataset=add_data(dataset,readGTGU.read(type,max_ele))
    return dataset