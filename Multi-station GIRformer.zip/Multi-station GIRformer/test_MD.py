import numpy as np
import read_all
import matplotlib.pyplot as plt
import model
import torch
import random
#设置随机种子
def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
#定义超参数
setup_seed(4689)
d_model=96;head_num=4;block_num=26
dropout=0.1;learning_rate=1e-4;batch_size=144;embedding_len=10;mask_percent=0.4
device='cuda' if torch.cuda.is_available() else 'cpu'
#读取数据
list_station=["TPW2"]
list_track=read_all.start(list_station,"test",max_ele=25)
#加载模型
model=model.Model(d_model,head_num,block_num,dropout,d_model//head_num,embedding_len,mask_percent)
model.load_state_dict(torch.load("model/ft2-1.pth"));model.to(device);model.eval()
#LSP计算反射高度
#w=open("output/test_MD.txt","w")
#w.write("t MD var TG\n")
list_t=[];list_MD=[];list_TG=[]
with torch.no_grad():
    for i in range(34):
        for j in range(len(list_track[i])):
            inputs_snr=list_track[i][j].list[:,0].reshape(1,-1);inputs_ele=list_track[i][j].list[:,1].reshape(1,-1)
            inputs_fre=list_track[i][j].fre.reshape(1,-1)
            tg_len=inputs_snr.shape[1]//10*10-(inputs_snr.shape[1]%10==0)*10
            start=random.randint(0,inputs_snr.shape[1]-tg_len)
            output,log_var=model.forward2(inputs_snr[:,start:start+tg_len],inputs_ele[:,start:start+tg_len],inputs_fre)
            var=torch.exp(log_var)
            output=output.clone().detach().numpy().item();var=var.clone().detach().numpy().item()
            #if abs(output-list_track[i][j].TG)<0.4:
            list_t.append(list_track[i][j].t);list_MD.append(output);list_TG.append(np.float32(list_track[i][j].TG))
                #w.write(f"{list_track[i][j].t} {output} {var} {list_track[i][j].TG}\n")
        print(i)
list_MD=np.array(list_MD);list_TG=np.array(list_TG);list_t=np.array(list_t)
# plt.scatter(list_t/86400,list_MD,s=0.3)
# plt.scatter(list_t/86400,list_TG,s=0.3)
# plt.savefig("fig/MD.png",dpi=600)
list_e=list_MD-list_TG
list_e0=list_e-np.mean(list_e)
print(np.mean(list_e),np.sqrt(np.mean(list_e**2)),len(list_e),np.sqrt(np.mean(list_e0**2)))