from function import cls
import os
import numpy as np
import datetime
import time
def read(type,max_ele=30):
    time_begin=datetime.datetime(2024,1,1)
    h0=5.838;station_name="SPBY"
    print(f"reading {station_name}")
    dataset=[]
    for _ in range(34):dataset.append([])
    #读取频率设置
    fre_path="ancillary/frequency.txt"
    r=open(fre_path,"r")
    r_lines=r.readlines()
    dict_fre={}
    for i in range(len(r_lines)):
        r_line_split=r_lines[i].split()
        dict_fre[r_line_split[0]]=float(r_line_split[1])
    r.close()
    #读取轨迹数据
    track_path=f"../data/track_{type}/"
    track_filename=os.listdir(track_path)
    #len_num=np.zeros(500)
    for filename in track_filename:
        if filename[0:4]!=station_name:continue
        print(f"reading {filename}")
        fre=dict_fre[filename[-8:-4]]
        r=open(track_path+filename,"r")
        r_lines=r.readlines()
        cnt=0
        for i in range(1,len(r_lines)):
            if cnt>0:cnt=cnt-1;continue
            r_line_split=r_lines[i].split()
            len_track=int(r_line_split[1])
            track0=cls.track(len_track,fre,h0)
            cnt=len_track
            minus=0
            #len_num[len_track]+=1
            for j in range(len_track):
                r_line_split=r_lines[i+j+1].split()
                t=float(r_line_split[0]);snr=float(r_line_split[1]);ele=float(r_line_split[2])
                if ele>max_ele:minus+=1;continue
                track0.add(t,snr,ele)
            len_track=len_track-minus
            if len_track<=60:continue
            track0.reshape()
            dataset[(len_track-61)//10].append(track0)
        r.close()
    #读取验潮站数据
    TG_path=f"../data/TG_{type}/"
    TG_filename=os.listdir(TG_path)
    list_TG_t=[];list_TG_h=[]
    for filename in TG_filename:
        if filename[0:4]!=station_name:continue
        r=open(TG_path+filename,"r")
        r_lines=r.readlines()
        for i in range(2,len(r_lines)-1):
            r_line_split=r_lines[i].split()
            r_split1=r_line_split[0].split('-')
            r_split2=r_line_split[1].split(':')
            t=datetime.datetime(int(r_split1[0]),int(r_split1[1]),int(r_split1[2]),int(r_split2[0]),int(r_split2[1]))
            dt=t-time_begin
            T=dt.days*86400+dt.seconds+dt.microseconds*1e-6
            h=float(r_line_split[2])
            list_TG_t.append(T);list_TG_h.append(h)
        r.close()
    list_TG_t=np.array(list_TG_t);list_TG_h=np.array(list_TG_h)
    #数据匹配
    def find(begin,end,tt):
        if begin==end:
            if begin>=5 and len(list_TG_t)-begin>5:
                list_tt=[];list_hh=[]
                for i in range(begin-5,begin+6):
                    list_tt.append(list_TG_t[i]-tt);list_hh.append(list_TG_h[i])
                list_tt=np.array(list_tt);list_hh=np.array(list_hh)
                coef=np.polyfit(list_tt,list_hh,1);poly=np.poly1d(coef);deriv=poly.deriv()
                coef2=np.polyfit(list_tt,list_hh,2);poly2=np.poly1d(coef2);deriv2=poly2.deriv()
                if abs(poly(0))>30:return list_TG_h[begin],0
                return poly(0),deriv2(0)
            else:return list_TG_h[begin],0
        mid=(begin+end)//2
        if tt<list_TG_t[mid]:return find(begin,mid,tt)
        if mid+1==len(list_TG_t):return list_TG_t[mid],0
        if abs(tt-list_TG_t[mid])<abs(tt-list_TG_t[mid+1]):
            if mid>=5 and len(list_TG_t)-mid>5:
                list_tt=[];list_hh=[]
                for i in range(mid-5,mid+6):
                    list_tt.append(list_TG_t[i]-tt);list_hh.append(list_TG_h[i])
                list_tt=np.array(list_tt);list_hh=np.array(list_hh)
                coef=np.polyfit(list_tt,list_hh,1);poly=np.poly1d(coef);deriv=poly.deriv()
                coef2=np.polyfit(list_tt,list_hh,2);poly2=np.poly1d(coef2);deriv2=poly2.deriv()
                if abs(poly(0))>30:return list_TG_h[mid],0
                return poly(0),deriv2(0)
            else:return list_TG_h[mid],0
        return find(mid+1,end,tt)
    for i in range(34):
        for j in range(len(dataset[i])):
            track0=dataset[i][j]
            h,doth=find(0,list_TG_t.shape[0],track0.t)
            track0.TG=h0-h;track0.dh=doth
            for k in range(track0.rd):
                h,_=find(0,list_TG_t.shape[0],track0.t_MD[k])
                track0.TG_MD[k]=h0-h
    return dataset