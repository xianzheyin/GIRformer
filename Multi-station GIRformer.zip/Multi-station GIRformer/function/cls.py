import numpy as np
import random
from torch.utils.data import Dataset
import astropy
#轨迹类
class track():
    def __init__(self,len_track,fre,h0):
        self.len=len_track;self.fre=np.array([fre])
        self.list=[];self.h0=h0;self.TG=0
        self.list_t=[]
    def add(self,t,snr,ele):
        self.list.append([snr,ele]);self.list_t.append(t)
    def reshape(self):
        self.list=np.array(self.list)
        list_ele=self.list[:,1];list_snr=self.list[:,0]
        #去除高阶项
        poly_snr=np.polyfit(list_ele,list_snr,2)
        poly_plt=np.poly1d(poly_snr)
        snr_dire=poly_plt(list_ele)
        snr_refl=list_snr-snr_dire
        self.list[:,0]=snr_refl
        self.list_t=np.array(self.list_t)
        self.t=(self.list_t[0]+self.list_t[-1])/2
        #创建时间集
        rd=self.list.shape[0]-(self.list.shape[0]//10*10-(self.list.shape[0]%10==0)*10)+1
        self.t_MD=np.zeros(rd);self.TG_MD=np.zeros(rd)
        for i in range(rd):
            self.t_MD[i]=(self.list_t[i]+self.list_t[-rd+i])/2
        self.rd=rd
    def LSP_analysis(self):
        #LSP频谱分析高度
        list_sinele=self.list[:,1];list_dsnr=self.list[:,0]
        list_sinele0=[];list_dsnr0=[]
        for i in range(len(list_sinele)):
            #if list_sinele[i]>15:continue
            list_sinele0.append(list_sinele[i]);list_dsnr0.append(list_dsnr[i])
        if len(list_sinele0)<50:self.LS=100;return
        list_sinele=np.array(list_sinele0);list_dsnr=np.array(list_dsnr0)
        for i in range(len(list_sinele)):list_sinele[i]=np.sin(list_sinele[i]*np.pi/180)
        fre_snr,power_snr=astropy.timeseries.LombScargle(list_sinele,list_dsnr).autopower()
        h_snr=fre_snr*self.fre/2
        #保留指定高度部分
        h2_snr=[];p2_snr=[]
        for i in range(len(h_snr)):
            if h_snr[i]<15:
                h2_snr.append(h_snr[i]);p2_snr.append(power_snr[i])
            else:break
        try:rh=h2_snr[np.argmax(p2_snr)]
        except:rh=10086
        self.LS=rh
    def harmony(self):
        if self.LS==100:self.e=1;self.dote=1;return
        mid=len(self.list)//2
        mid_t=(self.list_t[0]+self.list_t[-1])/2
        while(abs(self.list_t[mid-1]-mid_t)<abs(self.list_t[mid]-mid_t)):mid=mid-1
        while(abs(self.list_t[mid+1]-mid_t)<abs(self.list_t[mid]-mid_t)):mid=mid+1
        list_sample_t=[];list_sample_e=[]
        for i in range(5,-1,-1):
            list_sample_t.append(self.list_t[mid-i]);list_sample_e.append(self.list[mid-i][1])
        for i in range(5):
            list_sample_t.append(self.list_t[mid+i+1]);list_sample_e.append(self.list[mid+i+1][1])
        coef=np.polyfit(list_sample_t,list_sample_e,1)
        poly=np.poly1d(coef);deriv=poly.deriv()
        self.e=poly(mid_t);self.dote=deriv(mid_t)
        self.e=self.e/180*np.pi;self.dote=self.dote/180*np.pi
#轨迹数据集
class trackset0(Dataset):
    def __init__(self,list_track):self.data=list_track
    def __len__(self):return len(self.data)
    def __getitem__(self,idx):
        track0=self.data[idx]
        tg_len=track0.list.shape[0]//10*10-(track0.list.shape[0]%10==0)*10
        start=random.randint(0,track0.list.shape[0]-tg_len)
        return track0.list[start:start+tg_len,0],track0.list[start:start+tg_len,1],track0.fre
class trackset1(Dataset):
    def __init__(self,list_track):self.data=list_track
    def __len__(self):return len(self.data)
    def __getitem__(self,idx):
        track0=self.data[idx]
        tg_len=track0.list.shape[0]//10*10-(track0.list.shape[0]%10==0)*10
        start=random.randint(0,track0.list.shape[0]-tg_len)
        return track0.list[start:start+tg_len,0],track0.list[start:start+tg_len,1],track0.TG_MD[start],track0.fre