import subprocess
import sys
import threading
import os

def run_script(script_name):
    """
    运行单个子脚本，并实时输出其标准输出和标准错误。
    """
    print(f"Running {script_name}...")

    # 使用 python -u 确保子进程输出无缓冲
    cmd = [sys.executable, '-u', script_name]

    # 启动子进程，将标准输出和错误重定向到管道
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,          # 以文本模式读取
        bufsize=1           # 行缓冲
    )

    def read_output(pipe, stream):
        """
        从管道读取每一行并实时写入指定的输出流（stdout 或 stderr）。
        """
        for line in iter(pipe.readline, ''):
            # 直接输出，保留原换行符，并立即刷新
            print(line, end='', file=stream, flush=True)
        pipe.close()

    # 创建两个线程分别读取 stdout 和 stderr
    t_out = threading.Thread(target=read_output, args=(proc.stdout, sys.stdout))
    t_err = threading.Thread(target=read_output, args=(proc.stderr, sys.stderr))
    t_out.start()
    t_err.start()

    # 等待子进程结束
    return_code = proc.wait()

    # 等待所有输出被读取完毕
    t_out.join()
    t_err.join()

    if return_code != 0:
        print(f"Error: {script_name} exited with code {return_code}", file=sys.stderr)
        return False
    else:
        print(f"{script_name} finished successfully.")
        return True

def main():
    # 用户在此指定要运行的子脚本列表（按顺序）
    scripts = [
        #'train0.py',
        'train1.py',
        'train2.py',
        'train3.py',
        'plt_loss_all.py',
        'test_MD.py',
    ]

    for script in scripts:
        if not os.path.exists(script):
            print(f"Script {script} not found. Skipping.", file=sys.stderr)
            continue

        success = run_script(script)
        if not success:
            # 遇到错误时停止运行后续脚本（可根据需求调整）
            print("Stopping due to error.", file=sys.stderr)
            sys.exit(1)

    print("All scripts completed.")

if __name__ == '__main__':
    main()