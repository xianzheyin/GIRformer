import numpy as np
import os
import matplotlib.pyplot as plt
import datetime
import time
from matplotlib.lines import Line2D
def read_LS(name):
    r=open(f"output/test_LS_{name}.txt","r")
    t=[];LS=[];dote=[];e=[];Amax=[];PNR=[]
    r_lines=r.readlines()
    for i in range(1,len(r_lines)):
            r_line_split=r_lines[i].split()
            t.append(float(r_line_split[0])-882*86400);LS.append(float(r_line_split[1]))
            e.append(float(r_line_split[5]));dote.append(float(r_line_split[6]))
            Amax.append(float(r_line_split[7]));PNR.append(float(r_line_split[8]))
    t=np.array(t);LS=np.array(LS);dote=np.array(dote);e=np.array(e);Amax=np.array(Amax);PNR=np.array(PNR)
    idx = np.argsort(t)
    return t[idx],LS[idx],dote[idx],e[idx],Amax[idx],PNR[idx]
def read_MD(name):
    r=open(f"output/test_MD_{name}.txt","r")
    t=[];MD=[];var=[]
    r_lines=r.readlines()
    for i in range(1,len(r_lines)):
            r_line_split=r_lines[i].split()
            t.append(float(r_line_split[0])-882*86400);MD.append(float(r_line_split[1]));var.append(float(r_line_split[2]))
    t=np.array(t);MD=np.array(MD);var=np.array(var)
    idx = np.argsort(t)
    return t[idx],MD[idx],var[idx]
def read_MD1(name):
    r=open(f"output/test_MD1_{name}.txt","r")
    t=[];MD=[];var=[]
    r_lines=r.readlines()
    for i in range(1,len(r_lines)):
            r_line_split=r_lines[i].split()
            t.append(float(r_line_split[0])-882*86400);MD.append(float(r_line_split[1]));var.append(float(r_line_split[2]))
    t=np.array(t);MD=np.array(MD);var=np.array(var)
    idx = np.argsort(t)
    return t[idx],MD[idx],var[idx]
#读取观测数据
SPBY_t_LS,SPBY_h_LS,SPBY_dote_LS,SPBY_e_LS,SPBY_Amax_LS,SPBY_PNR_LS=read_LS("SPBY")
SPBY_t_MD,SPBY_h_MD,SPBY_var_MD=read_MD("SPBY")
SPBY_t_MD1,SPBY_h_MD1,SPBY_var_MD1=read_MD1("SPBY")
# plt.scatter(SPBY_t_LS/86400,SPBY_Amax_LS,s=0.2)
# plt.show()
def estimate_height_at_tt(list_t_inv, list_h_inv, list_var_inv,
                         tt, thre, min_points=2, t_tol=None, verbose=False):
    """
    加权线性拟合估计 tt 时刻的高度，逐轮剔除离群点（每轮最多剔除 1 个）。
    当 t 全部相同（或极差≈0）时自动降级为加权平均，避免 SVD 不收敛。

    参数
    ----
    list_t_inv, list_h_inv : array_like   时间序列与对应高度
    list_var_inv : array_like             每个点的预估权重（越大越可信）
    tt : float                            需要估计高度的时间点
    thre : float                          绝对误差阈值，超过则剔除该点
    min_points : int                      允许拟合的最少点数（>=2）
    t_tol : float or None                 判定 t 退化的容差；None 时按 t0 的量级自动取
    verbose : bool                        打印每轮剔除信息

    返回
    ----
    h_tt : float        tt 时刻的加权高度估计（无法估计时返回 nan）
    coef : ndarray or None   最终拟合系数 [a, b]（退化时 a=0）
    info : dict         {'keep_idx','removed_idx','residual_max','degenerate','t0'}
    """
    t = np.asarray(list_t_inv, dtype=float)
    h = np.asarray(list_h_inv, dtype=float)
    w = np.asarray(list_var_inv, dtype=float)

    # 基础清洗
    valid = np.isfinite(t) & np.isfinite(h) & np.isfinite(w) & (w > 0)
    keep = np.where(valid)[0]

    t0 = float(np.mean(t[keep])) if keep.size else 0.0
    # 相对容差：大时间戳下 float 精度有限，用相对判据更稳
    if t_tol is None:
        t_tol = 1e-12 * max(1.0, abs(t0))

    coef = None
    removed = []
    max_res = np.nan
    degenerate = False

    while len(keep) >= min_points:
        tk = t[keep] - t0
        hk = h[keep]
        wk = w[keep]

        # ① 每轮动态清洗，防止迭代中引入 NaN/Inf
        cv = np.isfinite(tk) & np.isfinite(hk) & np.isfinite(wk) & (wk > 0)
        if not np.all(cv):
            keep = keep[cv]
            continue

        # ② 判断 t 是否退化（极差≈0 → 斜率不可辨识）
        span = float(np.ptp(tk))
        degenerate = span <= t_tol

        if degenerate:
            # ③ 降级为加权平均（常数拟合 h = b）
            b = float(np.sum(wk * hk) / np.sum(wk))
            coef = np.array([0.0, b])
            pred = np.full_like(hk, b)
        else:
            # 正常加权线性拟合：polyfit 的 w 参数是 1/sigma
            sigma = 1.0 / np.sqrt(wk)
            coef = np.polyfit(tk, hk, 1, w=sigma)
            pred = np.polyval(coef, tk)

        # ④ 剔除逻辑（退化 / 非退化完全一致）
        abs_err = np.abs(hk - pred)
        j = int(np.argmax(abs_err))
        max_res = float(abs_err[j])
        if max_res <= thre:
            break                          # 全部合格
        if len(keep) <= min_points:
            break                          # 再删就无法估计

        removed.append(int(keep[j]))
        if verbose:
            mode = "加权平均" if degenerate else "线性拟合"
            print(f"[剔除|{mode}] idx={keep[j]}, t={t[keep[j]]:.6g}, "
                  f"残差={max_res:.4g} > thre={thre}")
        keep = np.delete(keep, j)          # 每轮只删一个

    if coef is None:
        return np.nan, None, {"keep_idx": keep, "removed_idx": removed,
                              "residual_max": max_res,
                              "degenerate": degenerate, "t0": t0}

    # ⑤ 退化时 polyval([0,b], anything)=b，预测自然正确
    h_tt = float(np.polyval(coef, tt - t0))
    info = {"keep_idx": keep, "removed_idx": removed,
            "residual_max": max_res, "degenerate": degenerate, "t0": t0}
    return h_tt, coef, info
#读取验潮站数据
TG_path=f"TG/"
time_begin=datetime.datetime(2026,6,1)
TG_filename=os.listdir(TG_path)
list_TG_t=[];list_TG_h=[]
for filename in TG_filename:
    if filename[0:4]!="SPBY":continue
    r=open(TG_path+filename,"r")
    r_lines=r.readlines()
    for i in range(2,len(r_lines)-1):
        r_line_split=r_lines[i].split()
        r_split1=r_line_split[0].split('-')
        r_split2=r_line_split[1].split(':')
        t=datetime.datetime(int(r_split1[0]),int(r_split1[1]),int(r_split1[2]),int(r_split2[0]),int(r_split2[1]))
        dt=t-time_begin
        T=dt.days*86400+dt.seconds+dt.microseconds*1e-6
        h=float(r_line_split[2])
        list_TG_t.append(T);list_TG_h.append(h)
    r.close()
list_TG_t=np.array(list_TG_t);list_TG_h=np.array(list_TG_h)
# plt.scatter(list_TG_t/86400,list_TG_h,s=0.2)
# plt.show()
#LS
time_win=135;time_inv=6;flag_l=0;flag_r=0;thre=0.3
interval_MD=[];interval_t_MD=[]
for tt in range(4*3600,61*86400-4*3600,time_inv*60):
    interval_t_MD.append(tt)
    while SPBY_t_LS[flag_l]<tt-time_win*30:flag_l+=1
    while SPBY_t_LS[flag_r]<tt+time_win*30:flag_r+=1
    list_t_inv=[];list_h_inv=[];list_var_inv=[]
    for i in range(flag_l,flag_r):
         if SPBY_h_LS[i]>5.5 or SPBY_h_LS[i]<3.5:continue
         if SPBY_PNR_LS[i]<6:continue
         if SPBY_Amax_LS[i]<0.3:continue
         list_t_inv.append(SPBY_t_LS[i]);list_h_inv.append(SPBY_h_LS[i]);list_var_inv.append(1)
    list_t_inv=np.array(list_t_inv);list_h_inv=np.array(list_h_inv);list_var_inv=np.array(list_var_inv)
    h_tt,_,_=estimate_height_at_tt(list_t_inv, list_h_inv, list_var_inv,tt,thre)
    #if h_tt>6:print(list_t_inv,list_h_inv,tt,h_tt);time.sleep(0.2)
    interval_MD.append(h_tt)
interval_MD=np.array(interval_MD);interval_t_MD=np.array(interval_t_MD)
# plt.scatter(interval_t_MD,interval_MD,s=0.2)
# plt.show()
#MD1
#二分查找
def _bisect_left(arr, x):
    """返回第一个 arr[i] >= x 的下标，等价于 np.searchsorted(arr, x, 'left')"""
    lo, hi = 0, len(arr)
    while lo < hi:
        mid = (lo + hi) // 2
        if arr[mid] < x:
            lo = mid + 1
        else:
            hi = mid
    return lo
def find_nearest_h_loop(list_TG_t, list_TG_h, interval_t_MD):
    n = len(list_TG_t)
    out = np.empty(len(interval_t_MD), dtype=np.asarray(list_TG_h).dtype)
    for k, q in enumerate(interval_t_MD):
        idx = _bisect_left(list_TG_t, q)

        if idx == 0:
            j = 0
        elif idx == n:
            j = n - 1
        else:
            j = idx - 1 if (q - list_TG_t[idx - 1]) <= (list_TG_t[idx] - q) else idx

        out[k] = -list_TG_h[j]
    return out
interval_MD_TG=find_nearest_h_loop(list_TG_t, list_TG_h, interval_t_MD)
interval_MD=interval_MD-np.mean(interval_MD)+np.mean(interval_MD_TG)
interval_MD_e=interval_MD-interval_MD_TG
print(np.sqrt(np.mean(interval_MD_e**2)))
plt.scatter(interval_t_MD,interval_MD,s=0.2,c='k')
plt.plot(interval_t_MD,interval_MD_TG,linewidth=0.6)
plt.show()
w=open("LS_out.txt","w")
for i in range(len(interval_t_MD)):
    w.write(f"{interval_t_MD[i]},{interval_MD[i]},{interval_MD_TG[i]}\n")