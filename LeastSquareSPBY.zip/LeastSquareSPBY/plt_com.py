import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
#LS
r=open("LS_out.txt","r")
list_TG=[];list_t=[];list_h_LS=[]
r_lines=r.readlines()
for i in range(len(r_lines)):
    r_line_split=r_lines[i].split(",")
    TG=float(r_line_split[2]);LS=float(r_line_split[1]);t=float(r_line_split[0])
    list_TG.append(TG);list_t.append(t);list_h_LS.append(LS)
list_TG=np.array(list_TG);list_t=np.array(list_t);list_h_LS=np.array(list_h_LS)
#MD
r=open("MD_out.txt","r")
list_h_MD=[]
r_lines=r.readlines()
for i in range(len(r_lines)):
    r_line_split=r_lines[i].split(",")
    MD=float(r_line_split[1])
    list_h_MD.append(MD)
list_h_MD=np.array(list_h_MD)
#MD1
r=open("MD1_out.txt","r")
list_h_MD1=[]
r_lines=r.readlines()
for i in range(len(r_lines)):
    r_line_split=r_lines[i].split(",")
    MD1=float(r_line_split[1])
    list_h_MD1.append(MD1)
list_h_MD1=np.array(list_h_MD1)
# plt.scatter(list_t/86400,list_TG-list_h_LS,s=0.2)
# plt.scatter(list_t/86400,list_TG-list_h_MD,s=0.2)
# plt.scatter(list_t/86400,list_TG-list_h_MD1,s=0.2)
# plt.savefig("com.png",dpi=600)
import matplotlib as mpl
import matplotlib.pyplot as plt

# ================= SCI 论文配图全局风格 =================
mpl.rcParams.update({
    'font.family'      : 'serif',
    'font.serif'       : ['Times New Roman', 'DejaVu Serif'],
    'mathtext.fontset' : 'stix',
    'font.size'        : 15,

    'axes.labelsize'   : 17,
    'xtick.labelsize'  : 15,
    'ytick.labelsize'  : 15,
    'legend.fontsize'  : 14,

    'axes.linewidth'   : 1.2,
    'xtick.direction'  : 'in',
    'ytick.direction'  : 'in',
    'xtick.top'        : True,
    'ytick.right'      : True,
    'xtick.major.size' : 6,
    'ytick.major.size' : 6,
    'xtick.minor.size' : 3,
    'ytick.minor.size' : 3,
    'xtick.major.width': 1.2,
    'ytick.major.width': 1.2,
    'xtick.minor.visible': True,
    'ytick.minor.visible': True,

    'savefig.dpi'      : 600,
    'savefig.bbox'     : 'tight',
    'savefig.format'   : 'png',
})

# ================= 数据 =================
x = list_t / 86400.0

data = [
    (list_TG - list_h_LS,  '#79B9DC', '(a)'),
    (list_TG - list_h_MD,  '#F1A078', '(b)'),
    (list_TG - list_h_MD1, '#73C5B0', '(c)'),
]

# ================= 绘图 =================
# 原 figsize=(7.5, 9.5)，高度减半 → (7.5, 4.75)
fig, axes = plt.subplots(3, 1, figsize=(7.5, 4.75), sharex=True)

for ax, (y, color, tag) in zip(axes, data):
    ax.scatter(x, y,
               s=2,
               c=color,
               alpha=0.9,
               edgecolors='none',
               rasterized=True)

    ax.set_ylabel('e (m)')
    ax.minorticks_on()
    ax.tick_params(which='both', direction='in', top=True, right=True)

    ax.text(0.02, 0.95, tag,
            transform=ax.transAxes,
            fontsize=18, fontweight='bold',
            va='top', ha='left')
    ax.set_ylim([-0.3,0.3])
axes[-1].set_xlabel('Time (day)')

fig.align_ylabels(axes)

# 关键：图变矮后，间距与边距按比例收紧，保证三行等高、等距
plt.subplots_adjust(
    hspace=0.04,     # 原 0.08 → 减半，避免压扁后间距显得过大
    left=0.13,
    right=0.97,
    top=0.97,
    bottom=0.12,     # 底部略增，给 x 轴标签留空间
)

plt.savefig("com.png", dpi=600)
# plt.savefig("com.pdf")
plt.show()