import numpy as np
import read_all
import matplotlib.pyplot as plt
import time
#读取数据
list_station=["SC02"]
list_track=read_all.start(list_station,"test",max_ele=15)
#LSP计算反射高度
# w=open("output/test_LS.txt","w")
# w.write("t LS LS0 TG doth\n")
list_t=[];list_LS=[];list_TG=[]
cnt=0
for i in range(34):
    for j in range(len(list_track[i])):
        cnt=cnt+1
        list_track[i][j].LSP_analysis()
        list_track[i][j].harmony()
        LS0=list_track[i][j].LS
        list_track[i][j].LS=list_track[i][j].LS#+list_track[i][j].dh*np.tan(list_track[i][j].e)/list_track[i][j].dote
        #if abs(list_track[i][j].LS-list_track[i][j].TG)<0.4:
        list_t.append(list_track[i][j].t);list_LS.append(list_track[i][j].LS);list_TG.append(list_track[i][j].TG)
        # w.write(f"{list_track[i][j].t} {list_track[i][j].LS} {LS0} {list_track[i][j].TG} {list_track[i][j].dh}\n")
    print(i)
list_LS=np.array(list_LS);list_TG=np.array(list_TG);list_t=np.array(list_t)
#plt.scatter(list_t/86400,list_LS,s=0.3)
#plt.scatter(list_t/86400,list_TG,s=0.3)
#plt.ylim(-5,12)
#plt.savefig("LS.png",dpi=600)
list_e=list_LS-list_TG
list_e0=list_e-np.mean(list_e)
print(np.mean(list_e),np.sqrt(np.mean(list_e**2)),len(list_e),np.sqrt(np.mean(list_e0**2)))
print(cnt,len(list_e)/cnt)